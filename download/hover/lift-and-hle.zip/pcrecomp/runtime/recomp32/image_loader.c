/*
 * image_loader.c - generic PE image loader for the recomp32 runtime.
 * See image_loader.h. Forged on the Fury3 (1995) recompilation.
 */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "image_loader.h"

#pragma pack(push, 1)
typedef struct {
    char     name[8];
    uint32_t vsize;   /* VirtualSize        */
    uint32_t vaddr;   /* VirtualAddress (RVA)*/
    uint32_t rsize;   /* SizeOfRawData      */
    uint32_t roff;    /* PointerToRawData   */
    uint32_t reloc_ptr, lineno_ptr;
    uint16_t nreloc, nlineno;
    uint32_t chr;     /* Characteristics    */
} recomp_sechdr_t;
#pragma pack(pop)

uint32_t recomp_load_image(const char* path, uint32_t image_base) {
    FILE* f = fopen(path, "rb");
    if (!f) { fprintf(stderr, "[loader] cannot open %s\n", path); return 0; }
    fseek(f, 0, SEEK_END);
    long sz = ftell(f);
    fseek(f, 0, SEEK_SET);
    if (sz <= 0x40) { fclose(f); return 0; }
    uint8_t* buf = (uint8_t*)malloc((size_t)sz);
    if (!buf) { fclose(f); return 0; }
    if (fread(buf, 1, (size_t)sz, f) != (size_t)sz) { fclose(f); free(buf); return 0; }
    fclose(f);

    if (buf[0] != 'M' || buf[1] != 'Z') { free(buf); fprintf(stderr, "[loader] not MZ\n"); return 0; }
    uint32_t e_lfanew = *(uint32_t*)(buf + 0x3C);
    uint8_t* nt = buf + e_lfanew;
    if (nt[0] != 'P' || nt[1] != 'E') { free(buf); fprintf(stderr, "[loader] not PE\n"); return 0; }

    uint16_t nsec   = *(uint16_t*)(nt + 6);
    uint16_t opt_sz = *(uint16_t*)(nt + 20);
    recomp_sechdr_t* sec = (recomp_sechdr_t*)(nt + 24 + opt_sz);

    uint32_t max_end = 0;
    for (int i = 0; i < nsec; i++) {
        uint32_t vs  = sec[i].vsize ? sec[i].vsize : sec[i].rsize;
        uint32_t end = sec[i].vaddr + vs;
        if (end > max_end) max_end = end;
    }
    uint32_t span = (max_end + 0xFFFu) & ~0xFFFu;

    void* view = VirtualAlloc((void*)(uintptr_t)image_base, span,
                              MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);
    if (!view) {
        /* Already reserved for us -- a launcher that held the range through
         * loader init (see the MSVC-host case) leaves it reserved, and
         * MEM_RESERVE over an existing reservation fails. Commit into it, but
         * only into a reservation that is exactly ours: one that starts at the
         * image base and covers the whole image. Committing into somebody
         * else's (a heap segment the process made before main) "worked", and
         * the image's tail vanished when its owner released it: KISS Psycho
         * Circus, based at 0x01CA0000, lost its .rdata minutes in. */
        MEMORY_BASIC_INFORMATION mbi;
        if (VirtualQuery((void*)(uintptr_t)image_base, &mbi, sizeof mbi) && mbi.State == MEM_RESERVE &&
            (uint32_t)(uintptr_t)mbi.AllocationBase == image_base && mbi.RegionSize >= span)
            view = VirtualAlloc((void*)(uintptr_t)image_base, span,
                                MEM_COMMIT, PAGE_EXECUTE_READWRITE);
        else if (mbi.State != MEM_FREE)
            fprintf(stderr, "[loader] 0x%08X+0x%X is already in use (allocation at %p, state %lX): hold it "
                    "from process start (native32_hold_image)\n", image_base, span, mbi.AllocationBase,
                    (unsigned long)mbi.State);
    }
    if (!view) {
        fprintf(stderr, "[loader] VirtualAlloc fixed @ 0x%08X failed (link host at a high base)\n",
                image_base);
        free(buf);
        return 0;
    }
    memset(view, 0, span);  /* zeroes .bss */

    /* The headers, too. Windows maps SizeOfHeaders bytes at the image base, and
     * code does read them back -- walking your own import directory to find an
     * IAT slot by name needs e_lfanew to be there. Copying only sections leaves
     * that whole region zeroed. */
    {
        uint32_t hdr = *(uint32_t*)(nt + 24 + 60);   /* OptionalHeader.SizeOfHeaders */
        if (hdr > (uint32_t)sz) hdr = (uint32_t)sz;
        if (hdr > span) hdr = span;
        memcpy(view, buf, hdr);
    }

    for (int i = 0; i < nsec; i++) {
        /* "Uninitialized" is PointerToRawData == 0 -- no file backing -- not
         * SizeOfRawData == 0. MSVC happens to set both to 0 for .bss, so the
         * size test worked by coincidence; Watcom does not. It puts the *memory*
         * size in SizeOfRawData and leaves PointerToRawData 0, so on a Watcom
         * binary the size test treats .bss as initialized and copies
         * SizeOfRawData bytes from file offset 0 -- for Nocturne, 42 MB read out
         * of a 1.9 MB buffer, over a .bss that is supposed to stay zeroed. */
        if (sec[i].roff == 0) continue;
        uint32_t va = image_base + sec[i].vaddr;
        uint32_t n  = sec[i].rsize;
        /* Windows maps a section's file data up to its VirtualSize rounded up
         * to the page, not to the VirtualSize itself: bytes past it in the last
         * page come from the file. Tiberian Sun's Game.exe keeps a patch's code
         * there (0x006C9A10, past .text's 0x006C9A0D), and cut at VirtualSize
         * it ran as zeroes, `add [eax], al`, and faulted. */
        if (sec[i].vsize && ((sec[i].vsize + 0xFFFu) & ~0xFFFu) < n) n = (sec[i].vsize + 0xFFFu) & ~0xFFFu;
        /* Never read past what the file actually holds: these headers come from
         * disk and a truncated or hostile one must not turn into an overread. */
        if (sec[i].roff >= (uint32_t)sz) continue;
        if (n > (uint32_t)sz - sec[i].roff) n = (uint32_t)sz - sec[i].roff;
        if (sec[i].vaddr >= span) continue;
        if (n > span - sec[i].vaddr) n = span - sec[i].vaddr;
        memcpy((void*)(uintptr_t)va, buf + sec[i].roff, n);
    }
    free(buf);
    return span;
}
