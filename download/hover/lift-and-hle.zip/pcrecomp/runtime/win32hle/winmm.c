/*
 * winmm.c - win32hle WINMM: multimedia timers, joystick, waveOut audio, MCI;
 * no mixer and no recording device.
 * On libc for timing; audio is "accept and retire" (a silent device that
 * completes every buffer immediately, so a game's double-buffered mixer thread
 * keeps cycling without a real sound card); no joystick; MCI stubbed. Real SDL
 * audio can replace the waveOut path later without touching callers.
 */
#define _GNU_SOURCE
#include <stdint.h>
#include <time.h>
#include <unistd.h>
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "win32hle.h"

#define MMSYSERR_NOERROR  0u
#define MMSYSERR_ERROR    1u
#define JOYERR_UNPLUGGED  167u
#define WHDR_DONE         0x00000001u
#define WHDR_INQUEUE      0x00000010u

/* --- multimedia timer --- */
static void m_timeGetTime(void) {
    struct timespec ts; clock_gettime(CLOCK_MONOTONIC, &ts);
    RET((uint32_t)(ts.tv_sec * 1000u + ts.tv_nsec / 1000000u), 0);
}
static void m_timeBeginPeriod(void) { RET(MMSYSERR_NOERROR, 1); }
static void m_timeGetDevCaps(void) {           /* (&TIMECAPS, size) */
    if (A32(0) && A32(1) >= 8) MEM32(A32(0)) = 1, MEM32(A32(0) + 4) = 1000000;
    RET(MMSYSERR_NOERROR, 2);
}

/* --- multimedia timers ---
 * Each timer is a host thread that calls the guest's callback through
 * hle_call_guest, so the callback runs once it gets the machine, as on
 * Windows it runs on winmm's thread. timeKillEvent returns only once a
 * callback already under way has finished (giving the machine up while it
 * waits): a game frees what its callback uses right after the kill
 * (Tiberian Sun's movie audio, its bring-up log 8). */
#define MAX_MMTIMERS 32
static struct { volatile int used, killed, inflight; uint32_t id, delay, proc, user, flags; pthread_t thread; } g_mmt[MAX_MMTIMERS];
static uint32_t g_mmt_next = 1;
volatile unsigned hle_mmt_fired, hle_mmt_started;      /* a host's diagnostics */
static void *mmtimer(void *arg) {
    __sync_fetch_and_add(&hle_mmt_started, 1);
    int i = (int)(intptr_t)arg;
    uint32_t due = hle_ticks_ms() + g_mmt[i].delay;
    for (;;) {
        int32_t wait = (int32_t)(due - hle_ticks_ms());
        if (wait > 0) usleep((useconds_t)wait * 1000u);
        if (g_mmt[i].killed) break;
        __sync_fetch_and_add(&g_mmt[i].inflight, 1);
        if (!g_mmt[i].killed) {
            if (g_mmt[i].flags & 0x30u) {                /* TIME_CALLBACK_EVENT_SET / _PULSE: proc is an event */
                uint32_t h = g_mmt[i].proc;
                mach_enter();
                hle_set_event(h);
                mach_leave();
            } else {
                uint32_t a[5] = { g_mmt[i].id, 0, g_mmt[i].user, 0, 0 };
                hle_call_guest(g_mmt[i].proc, 5, a);
                __sync_fetch_and_add(&hle_mmt_fired, 1);
            }
        }
        __sync_fetch_and_sub(&g_mmt[i].inflight, 1);
        if (!(g_mmt[i].flags & 1u)) break;               /* TIME_ONESHOT */
        due += g_mmt[i].delay ? g_mmt[i].delay : 1;
        if ((int32_t)(hle_ticks_ms() - due) > 1000) due = hle_ticks_ms();   /* fell far behind: no catch-up storm */
    }
    g_mmt[i].used = 0;
    return NULL;
}
static void m_timeSetEvent(void) {             /* (delay, resolution, proc, user, flags) */
    for (int i = 0; i < MAX_MMTIMERS; i++)
        if (!g_mmt[i].used) {
            g_mmt[i].used = 1, g_mmt[i].killed = 0, g_mmt[i].inflight = 0;
            g_mmt[i].id = g_mmt_next++, g_mmt[i].delay = A32(0), g_mmt[i].proc = A32(2), g_mmt[i].user = A32(3), g_mmt[i].flags = A32(4);
            if (pthread_create(&g_mmt[i].thread, NULL, mmtimer, (void *)(intptr_t)i) != 0) { g_mmt[i].used = 0; RET(0, 5); }
            pthread_detach(g_mmt[i].thread);
            RET(g_mmt[i].id, 5);
        }
    RET(0, 5);
}
static void m_timeKillEvent(void) {
    for (int i = 0; i < MAX_MMTIMERS; i++)
        if (g_mmt[i].used && g_mmt[i].id == A32(0) && !g_mmt[i].killed) {
            g_mmt[i].killed = 1;
            if (!pthread_equal(g_mmt[i].thread, pthread_self()))
                while (g_mmt[i].inflight) { hle_block_begin(); usleep(200); hle_block_end(); }
            RET(MMSYSERR_NOERROR, 1);
        }
    RET(97u /* MMSYSERR_INVALPARAM */, 1);
}
static void m_timeEndPeriod(void)   { RET(MMSYSERR_NOERROR, 1); }

/* --- joystick: none present, so the game takes its keyboard/mouse path --- */
static void m_joyGetNumDevs(void)   { RET(0, 0); }
static void m_joyGetDevCapsA(void)  { RET(JOYERR_UNPLUGGED, 3); }
static void m_joyGetPos(void)       { RET(JOYERR_UNPLUGGED, 2); }
static void m_joyGetPosEx(void)     { RET(JOYERR_UNPLUGGED, 2); }

/* --- waveOut: a silent device that retires every buffer at once ---
 * waveOutOpen succeeds with a fake handle; waveOutWrite marks the WAVEHDR done
 * and not-in-queue, so a mixer that waits for buffers to drain keeps going. */
static void m_waveOutOpen(void) {              /* (&hwo, devID, &fmt, cb, inst, flags) */
    uint32_t ph = A32(0);
    if (ph) MEM32(ph) = 0x5A5E0001u;           /* a nonzero HWAVEOUT */
    RET(MMSYSERR_NOERROR, 6);
}
static void m_waveOutWrite(void) {             /* (hwo, lpWaveHdr, cbwh) */
    uint32_t wh = A32(1);
    if (wh) { MEM32(wh + 16) = (MEM32(wh + 16) | WHDR_DONE) & ~WHDR_INQUEUE; }
    RET(MMSYSERR_NOERROR, 3);
}
static void m_waveOutPrepareHeader(void)   { uint32_t wh=A32(1); if(wh) MEM32(wh+16)|=0x00000002u/*WHDR_PREPARED*/; RET(MMSYSERR_NOERROR, 3); }
static void m_waveOutUnprepareHeader(void) { uint32_t wh=A32(1); if(wh) MEM32(wh+16)&=~0x00000002u; RET(MMSYSERR_NOERROR, 3); }
static void m_waveOutReset(void)       { RET(MMSYSERR_NOERROR, 1); }
static void m_waveOutClose(void)       { RET(MMSYSERR_NOERROR, 1); }
static void m_waveOutGetNumDevs(void)  { RET(1, 0); }          /* one (silent) device */
static void m_waveOutGetDevCapsA(void) { RET(MMSYSERR_NOERROR, 3); }

/* The device's own volume, the id behind a handle: the one device, at full
 * volume (a caller's level is its own business: dsound.c mixes at the level
 * a buffer asks for). */
static void m_waveOutSetVolume(void)  { RET(MMSYSERR_NOERROR, 2); }
static void m_waveOutGetVolume(void)  { if (A32(1)) MEM32(A32(1)) = 0xFFFFFFFFu; RET(MMSYSERR_NOERROR, 2); }
static void m_waveOutGetID(void)      { if (A32(1)) MEM32(A32(1)) = 0; RET(MMSYSERR_NOERROR, 2); }

/* --- no mixer, no recording device ---
 * What Windows answers on a PC without either: no devices, an open of device
 * 0 refused as a bad id, and anything given a handle told it is not one. A
 * program that sets its card's levels through the mixer, or enumerates
 * inputs for a record page, carries on without them. */
#define MMSYSERR_BADDEVICEID  2u
#define MMSYSERR_INVALHANDLE  5u
static void m_none0(void)       { RET(0, 0); }                        /* mixerGetNumDevs, waveInGetNumDevs */
static void m_mixerOpen(void)   { if (A32(0)) MEM32(A32(0)) = 0; RET(MMSYSERR_BADDEVICEID, 5); }
static void m_waveInOpen(void)  { if (A32(0)) MEM32(A32(0)) = 0; RET(MMSYSERR_BADDEVICEID, 6); }
static void m_badhandle1(void)  { RET(MMSYSERR_INVALHANDLE, 1); }     /* (h) */
static void m_badhandle3(void)  { RET(MMSYSERR_INVALHANDLE, 3); }     /* (h, struct, size or flags) */

/* --- MCI (CD audio / command strings): not available --- */
static void m_mciSendStringA(void)     { RET(MMSYSERR_ERROR, 4); }
static void m_mciGetErrorStringA(void) { RET(0, 3); }          /* FALSE: no string */

/* --- mmio: RIFF files (WAVs) for reading ---
 * A file is read whole into memory at mmioOpenA, or a caller's buffer is
 * used as it stands (FOURCC_MEM). The direct-buffer calls (mmioGetInfo,
 * mmioAdvance, mmioSetInfo) then hand out that one buffer, which is the
 * whole file, so an advance never has to refill it. Writing is not done:
 * opening for write fails, as with a read-only disk. */
#define MMIOERR_CANNOTOPEN    257u
#define MMIOERR_CHUNKNOTFOUND 265u
#define FOURCC_MEM  0x204D454Du
#define FOURCC_RIFF 0x46464952u
#define FOURCC_LIST 0x5453494Cu
typedef struct { uint8_t *data; uint32_t len, pos; int owns; } hmmio;
static hmmio *MMIO(uint32_t h) { return (hmmio *)hle_handle_obj(h, HLE_H_MMIO); }
static void mmio_info(const hmmio *m, uint32_t info, uint32_t h) {   /* MMIOINFO over the whole file */
    MEM32(info + 20) = m->len, MEM32(info + 24) = hle_va(m->data);
    MEM32(info + 28) = hle_va(m->data) + m->pos, MEM32(info + 32) = hle_va(m->data) + m->len;
    MEM32(info + 36) = MEM32(info + 32), MEM32(info + 40) = 0, MEM32(info + 44) = m->len, MEM32(info + 68) = h;
}
static void m_mmioOpenA(void) {                          /* (name, MMIOINFO*, flags) */
    const char *name = ASTR(0);
    uint32_t info = A32(1), flags = A32(2);
    hmmio *m = (hmmio *)calloc(1, sizeof *m);
    if (info && MEM32(info + 4) == FOURCC_MEM && MEM32(info + 24)) {
        m->data = (uint8_t *)hle_ptr(MEM32(info + 24)), m->len = MEM32(info + 20);
    } else {
        char host[1024];
        FILE *f = !(flags & 0x1003u) && name && hle_host_path(name, host, sizeof host) ? fopen(host, "rb") : NULL;   /* not WRITE, READWRITE, CREATE */
        long n = -1;
        if (f && fseek(f, 0, SEEK_END) == 0 && (n = ftell(f)) >= 0) rewind(f);
        m->data = f && n >= 0 ? (uint8_t *)hle_alloc((uint32_t)n + 1) : NULL, m->len = (uint32_t)n, m->owns = 1;
        if (!m->data || fread(m->data, 1, (size_t)n, f) != (size_t)n) {
            if (f) fclose(f);
            hle_free(m->data), free(m);
            if (info) MEM32(info + 12) = MMIOERR_CANNOTOPEN;
            RET(0, 3);
        }
        fclose(f);
    }
    uint32_t h = hle_handle_alloc(HLE_H_MMIO, m);
    if (info) MEM32(info + 12) = 0;
    RET(h, 3);
}
static void m_mmioClose(void) {
    hmmio *m = MMIO(A32(0));
    if (!m) RET(MMSYSERR_ERROR, 2);
    if (m->owns) hle_free(m->data);
    free(m);
    hle_handle_close(A32(0));
    RET(0, 2);
}
static void m_mmioRead(void) {                           /* (h, buf, n) */
    hmmio *m = MMIO(A32(0));
    if (!m) RET(0xFFFFFFFFu, 3);
    uint32_t n = A32(2) < m->len - m->pos ? A32(2) : m->len - m->pos;
    memcpy(APTR(1), m->data + m->pos, n);
    m->pos += n;
    RET(n, 3);
}
static void m_mmioWrite(void) { RET(0xFFFFFFFFu, 3); }
static void m_mmioSeek(void) {                           /* (h, offset, origin) */
    hmmio *m = MMIO(A32(0));
    int64_t to = (int32_t)A32(1) + (int64_t)(A32(2) == 1 ? m ? m->pos : 0 : A32(2) == 2 ? m ? m->len : 0 : 0);
    if (!m || to < 0 || to > m->len) RET(0xFFFFFFFFu, 3);
    m->pos = (uint32_t)to;
    RET(m->pos, 3);
}
static void m_mmioDescend(void) {                        /* (h, MMCKINFO*, parent, flags) */
    hmmio *m = MMIO(A32(0));
    uint32_t ck = A32(1), parent = A32(2), flags = A32(3);
    uint32_t end = parent ? MEM32(parent + 12) + MEM32(parent + 4) : m ? m->len : 0;
    if (!m) RET(MMSYSERR_ERROR, 4);
    if (end > m->len) end = m->len;
    for (;;) {
        if (m->pos + 8 > end) RET(MMIOERR_CHUNKNOTFOUND, 4);
        uint32_t id, size, type = 0;
        memcpy(&id, m->data + m->pos, 4), memcpy(&size, m->data + m->pos + 4, 4);
        uint32_t data = m->pos + 8;
        int list = id == FOURCC_RIFF || id == FOURCC_LIST;
        if (list && data + 4 <= end) memcpy(&type, m->data + data, 4);
        int found = flags & 0x10 ? id == MEM32(ck)                                     /* FINDCHUNK */
                  : flags & 0x20 ? id == FOURCC_RIFF && type == MEM32(ck + 8)          /* FINDRIFF */
                  : flags & 0x40 ? id == FOURCC_LIST && type == MEM32(ck + 8) : 1;     /* FINDLIST */
        if (found) {
            MEM32(ck) = id, MEM32(ck + 4) = size, MEM32(ck + 8) = type, MEM32(ck + 12) = data, MEM32(ck + 16) = 0;
            m->pos = data + (list ? 4 : 0);
            RET(0, 4);
        }
        m->pos = data + size + (size & 1);
    }
}
static void m_mmioAscend(void) {                         /* (h, MMCKINFO*, flags) */
    hmmio *m = MMIO(A32(0));
    uint32_t ck = A32(1), to = MEM32(ck + 12) + MEM32(ck + 4);
    if (!m) RET(MMSYSERR_ERROR, 3);
    to += to & 1;
    m->pos = to < m->len ? to : m->len;
    RET(0, 3);
}
static void m_mmioGetInfo(void) {                        /* (h, MMIOINFO*, flags) */
    hmmio *m = MMIO(A32(0));
    if (!m) RET(MMSYSERR_ERROR, 3);
    memset(APTR(1), 0, 72);
    mmio_info(m, A32(1), A32(0));
    RET(0, 3);
}
static void m_mmioSetInfo(void) {                        /* (h, MMIOINFO*, flags): where pchNext got to */
    hmmio *m = MMIO(A32(0));
    if (!m) RET(MMSYSERR_ERROR, 3);
    uint32_t next = MEM32(A32(1) + 28) - hle_va(m->data);
    m->pos = next < m->len ? next : m->len;
    RET(0, 3);
}
static void m_mmioAdvance(void) {                        /* (h, MMIOINFO*, flags) */
    hmmio *m = MMIO(A32(0));
    if (!m) RET(MMSYSERR_ERROR, 3);
    if (A32(1)) { uint32_t next = MEM32(A32(1) + 28) - hle_va(m->data); m->pos = next < m->len ? next : m->len; mmio_info(m, A32(1), A32(0)); }
    RET(0, 3);
}
static void m_mmioSetBuffer(void) { RET(0, 4); }        /* the buffer is the whole file already */

/* mmioStringToFOURCCA(str, flags): the first four characters, padded with
 * spaces; MMIO_TOUPPER (0x10) upper-cases them. */
static void m_mmioStringToFOURCCA(void) {
    const char *s = ASTR(0);
    uint32_t fcc = 0;
    for (int i = 0, end = 0; i < 4; i++) {
        char c = !end && s && s[i] ? s[i] : (end = 1, ' ');
        if ((A32(1) & 0x10) && c >= 'a' && c <= 'z') c = (char)(c - 32);
        fcc |= (uint32_t)(uint8_t)c << (8 * i);
    }
    RET(fcc, 2);
}

const win32hle_shim win32hle_winmm[] = {
    { "mmioStringToFOURCCA",    m_mmioStringToFOURCCA },
    { "mmioOpenA", m_mmioOpenA }, { "mmioClose", m_mmioClose }, { "mmioRead", m_mmioRead }, { "mmioWrite", m_mmioWrite },
    { "mmioSeek", m_mmioSeek }, { "mmioDescend", m_mmioDescend }, { "mmioAscend", m_mmioAscend },
    { "mmioGetInfo", m_mmioGetInfo }, { "mmioSetInfo", m_mmioSetInfo }, { "mmioAdvance", m_mmioAdvance },
    { "mmioSetBuffer", m_mmioSetBuffer },
    { "timeGetTime",            m_timeGetTime },
    { "timeBeginPeriod",        m_timeBeginPeriod },
    { "timeEndPeriod",          m_timeEndPeriod },
    { "timeGetDevCaps",         m_timeGetDevCaps },
    { "timeSetEvent",           m_timeSetEvent },
    { "timeKillEvent",          m_timeKillEvent },
    { "joyGetNumDevs",          m_joyGetNumDevs },
    { "joyGetDevCapsA",         m_joyGetDevCapsA },
    { "joyGetPos",              m_joyGetPos },
    { "joyGetPosEx",            m_joyGetPosEx },
    { "waveOutOpen",            m_waveOutOpen },
    { "waveOutWrite",           m_waveOutWrite },
    { "waveOutPrepareHeader",   m_waveOutPrepareHeader },
    { "waveOutUnprepareHeader", m_waveOutUnprepareHeader },
    { "waveOutReset",           m_waveOutReset },
    { "waveOutClose",           m_waveOutClose },
    { "waveOutGetNumDevs",      m_waveOutGetNumDevs },
    { "waveOutGetDevCapsA",     m_waveOutGetDevCapsA },
    { "waveOutSetVolume",       m_waveOutSetVolume },
    { "waveOutGetVolume",       m_waveOutGetVolume },
    { "waveOutGetID",           m_waveOutGetID },
    { "mixerGetNumDevs",        m_none0 },
    { "mixerOpen",              m_mixerOpen },
    { "mixerClose",             m_badhandle1 },
    { "mixerGetLineInfoA",      m_badhandle3 },
    { "mixerGetLineControlsA",  m_badhandle3 },
    { "mixerGetControlDetailsA", m_badhandle3 },
    { "mixerSetControlDetails", m_badhandle3 },
    { "waveInGetNumDevs",       m_none0 },
    { "waveInOpen",             m_waveInOpen },
    { "waveInClose",            m_badhandle1 },
    { "waveInReset",            m_badhandle1 },
    { "waveInStart",            m_badhandle1 },
    { "waveInStop",             m_badhandle1 },
    { "waveInPrepareHeader",    m_badhandle3 },
    { "waveInUnprepareHeader",  m_badhandle3 },
    { "waveInAddBuffer",        m_badhandle3 },
    { "waveInGetPosition",      m_badhandle3 },
    { "mciSendStringA",         m_mciSendStringA },
    { "mciGetErrorStringA",     m_mciGetErrorStringA },
    { 0, 0 }
};
