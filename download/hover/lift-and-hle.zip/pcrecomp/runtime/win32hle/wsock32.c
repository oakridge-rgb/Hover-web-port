/*
 * wsock32.c - WSOCK32 (Winsock 1.1) on BSD sockets.
 *
 * Imported by ordinal as often as by name, so each shim is registered under
 * both ("wsock32.dll#115" and "WSAStartup"). A SOCKET is the host descriptor
 * plus 0x1000 (never 0, never INVALID_SOCKET). Internet sockets are real.
 *
 * IPX is IPXEmu's (the IPX-over-UDP wsock32.dll Westwood's games ship with
 * now), on the wire exactly: an IPX datagram socket is a UDP socket, an IPX
 * address's socket number is the UDP port and the first four bytes of its
 * node are the IPv4 address, and the payload goes as it is. So a game on this
 * host and the same game on Windows with IPXEmu see one LAN.
 *
 * WSAAsyncSelect is served by hle_ws_poll(), which the message pump calls: a
 * socket that has become readable posts its window message, as Winsock's
 * window-message notification does.
 */
#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <poll.h>
#include <netdb.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <ifaddrs.h>
#include <net/if.h>
#include <strings.h>
#include "win32hle.h"

#ifndef MSG_NOSIGNAL             /* macOS: the socket says so instead (SO_NOSIGPIPE, at creation) */
#define MSG_NOSIGNAL 0
#endif

#define SOCK_BASE 0x1000u
#define INVALID_SOCKET 0xFFFFFFFFu
#define SOCKET_ERROR   0xFFFFFFFFu
#define WSAEWOULDBLOCK   10035u
#define WSAEAFNOSUPPORT  10047u
#define WSAENOTSOCK      10038u
#define WSAEINVAL        10022u
#define WSAEADDRINUSE    10048u
#define WSAECONNRESET    10054u
#define WSAHOST_NOT_FOUND 11001u
#define FD_READ  0x01u
#define FD_WRITE 0x02u

static __thread uint32_t g_wsa_error;

static uint32_t wsa_errno(int e) {
    switch (e) {
    case EWOULDBLOCK: return WSAEWOULDBLOCK;
    case EADDRINUSE:  return WSAEADDRINUSE;
    case EINVAL:      return WSAEINVAL;
    case EBADF: case ENOTSOCK: return WSAENOTSOCK;
    case ECONNRESET: case ECONNREFUSED: return WSAECONNRESET;
    case EAFNOSUPPORT: return WSAEAFNOSUPPORT;
    default: return 10000u + (uint32_t)e;
    }
}
static int fd_of(uint32_t s) { return s >= SOCK_BASE && s < SOCK_BASE + 0x10000u ? (int)(s - SOCK_BASE) : -1; }
static uint8_t g_ipx[0x10000 / 8];                       /* which descriptors are IPX sockets */
static int is_ipx(int fd) { return fd >= 0 && fd < 0x10000 && (g_ipx[fd >> 3] >> (fd & 7) & 1); }
#define AF_IPX_WIN    6
#define NSPROTO_IPX   1000u
#define FAIL(n) do { g_wsa_error = wsa_errno(errno); RET(SOCKET_ERROR, n); } while (0)

/* sockaddr_in is laid out the same on both (family is a little-endian u16). */
static void to_host(const uint8_t *g, struct sockaddr_in *h) {
    memset(h, 0, sizeof *h);
    h->sin_family = AF_INET;
    memcpy(&h->sin_port, g + 2, 2);
    memcpy(&h->sin_addr, g + 4, 4);
}
static void to_guest(const struct sockaddr_in *h, uint8_t *g) {
    memset(g, 0, 16);
    g[0] = 2;
    memcpy(g + 2, &h->sin_port, 2);
    memcpy(g + 4, &h->sin_addr, 4);
}
/* sockaddr_ipx: family 6, netnum[4], nodenum[6], socket (network order). */
static void ipx_to_host(const uint8_t *g, struct sockaddr_in *h, int any) {
    memset(h, 0, sizeof *h);
    h->sin_family = AF_INET;
    memcpy(&h->sin_port, g + 12, 2);
    if (!any) memcpy(&h->sin_addr, g + 6, 4);
}
static void ipx_to_guest(const struct sockaddr_in *h, uint8_t *g, int self) {
    memset(g, 0, 14);
    g[0] = AF_IPX_WIN;
    if (self) g[11] = 1;                                 /* our own node: 00:00:00:00:00:01 */
    else memcpy(g + 6, &h->sin_addr, 4);                 /* a sender's: its address, then 00 00 */
    memcpy(g + 12, &h->sin_port, 2);
}

static void w_WSAStartup(void) {                         /* (version, &WSADATA) */
    uint8_t *d = (uint8_t *)APTR(1);
    if (d) {
        memset(d, 0, 400);
        d[0] = 1, d[1] = 1, d[2] = 2, d[3] = 2;          /* wVersion 1.1, wHighVersion 2.2 */
        strcpy((char *)d + 4, "win32hle Winsock");
        strcpy((char *)d + 4 + 257, "Running");
        *(uint16_t *)(d + 4 + 257 + 129) = 100;          /* iMaxSockets */
        *(uint16_t *)(d + 4 + 257 + 129 + 2) = 65467;    /* iMaxUdpDg */
    }
    RET(0, 2);
}
static void w_WSACleanup(void)     { RET(0, 0); }
static void w_WSAGetLastError(void){ RET(g_wsa_error, 0); }
static void w_WSASetLastError(void){ g_wsa_error = A32(0); RETV(1); }

static void w_socket(void) {                             /* (af, type, protocol) */
    int af = (int)A32(0), type = (int)A32(1), proto = (int)A32(2);
    int ipx = af == AF_IPX_WIN && type == 2 && (uint32_t)proto == NSPROTO_IPX;
    if (af != AF_INET && !ipx) {
        fprintf(stderr, "[wsock32] socket(af %d, type %d, protocol %d): not on this host\n", af, type, proto);
        g_wsa_error = WSAEAFNOSUPPORT;
        RET(INVALID_SOCKET, 3);
    }
    int fd = ipx ? socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP) : socket(AF_INET, type == 2 ? SOCK_DGRAM : SOCK_STREAM, proto);
#ifdef SO_NOSIGPIPE
    if (fd >= 0) { int one = 1; setsockopt(fd, SOL_SOCKET, SO_NOSIGPIPE, &one, sizeof one); }
#endif
    if (fd < 0 || fd >= 0x10000) { if (fd >= 0) close(fd); g_wsa_error = wsa_errno(errno); RET(INVALID_SOCKET, 3); }
    if (ipx) g_ipx[fd >> 3] |= (uint8_t)(1 << (fd & 7));
    else g_ipx[fd >> 3] &= (uint8_t)~(1 << (fd & 7));
    RET(SOCK_BASE + (uint32_t)fd, 3);
}
static void w_closesocket(void) {
    int fd = fd_of(A32(0));
    if (fd < 0 || close(fd) != 0) { g_wsa_error = WSAENOTSOCK; RET(SOCKET_ERROR, 1); }
    g_ipx[fd >> 3] &= (uint8_t)~(1 << (fd & 7));
    RET(0, 1);
}
static void w_bind(void) {                               /* (s, addr, len) */
    struct sockaddr_in a;
    int fd = fd_of(A32(0));
    if (is_ipx(fd)) ipx_to_host((const uint8_t *)APTR(1), &a, 1);   /* any address, the socket's port */
    else to_host((const uint8_t *)APTR(1), &a);
    if (bind(fd, (struct sockaddr *)&a, sizeof a) != 0) FAIL(3);
    RET(0, 3);
}
static void w_connect(void) {
    struct sockaddr_in a;
    to_host((const uint8_t *)APTR(1), &a);
    if (connect(fd_of(A32(0)), (struct sockaddr *)&a, sizeof a) != 0) FAIL(3);
    RET(0, 3);
}
static void w_listen(void) { if (listen(fd_of(A32(0)), (int)A32(1)) != 0) FAIL(2); RET(0, 2); }
static int nettrace(void) { static int on = -1; if (on < 0) on = getenv("HLE_NETTRACE") != NULL; return on; }
/* a datagram the guest broadcast (255.255.255.255), for a host that also
 * sends it elsewhere (game servers on the Internet that answer a LAN search) */
void (*hle_ws_broadcast_hook)(int fd, const void *buf, uint32_t len, unsigned port);
static void w_sendto(void) {                             /* (s, buf, len, flags, to, tolen) */
    struct sockaddr_in a;
    ssize_t n;
    if (A32(4)) {
        if (is_ipx(fd_of(A32(0)))) ipx_to_host((const uint8_t *)APTR(4), &a, 0);
        else to_host((const uint8_t *)APTR(4), &a);
        n = sendto(fd_of(A32(0)), APTR(1), A32(2), MSG_NOSIGNAL, (struct sockaddr *)&a, sizeof a);
        if (nettrace()) fprintf(stderr, "[net] sendto %s:%u %u bytes -> %d%s\n", inet_ntoa(a.sin_addr), ntohs(a.sin_port), A32(2), (int)n, n < 0 ? strerror(errno) : "");
        if (n >= 0 && hle_ws_broadcast_hook && !is_ipx(fd_of(A32(0))) && a.sin_addr.s_addr == htonl(INADDR_BROADCAST))
            hle_ws_broadcast_hook(fd_of(A32(0)), APTR(1), A32(2), ntohs(a.sin_port));
    }
    else n = send(fd_of(A32(0)), APTR(1), A32(2), MSG_NOSIGNAL);
    if (n < 0) FAIL(6);
    RET((uint32_t)n, 6);
}
static void w_send(void) { ssize_t n = send(fd_of(A32(0)), APTR(1), A32(2), MSG_NOSIGNAL); if (n < 0) FAIL(4); RET((uint32_t)n, 4); }
static void w_recvfrom(void) {                           /* (s, buf, len, flags, from, &fromlen) */
    struct sockaddr_in a;
    socklen_t al = sizeof a;
    ssize_t n = recvfrom(fd_of(A32(0)), APTR(1), A32(2), MSG_DONTWAIT, (struct sockaddr *)&a, &al);
    if (n < 0) FAIL(6);
    if (nettrace()) fprintf(stderr, "[net] recvfrom %s:%u %d bytes\n", inet_ntoa(a.sin_addr), ntohs(a.sin_port), (int)n);
    int ipx = is_ipx(fd_of(A32(0)));
    if (A32(4)) { if (ipx) ipx_to_guest(&a, (uint8_t *)APTR(4), 0); else to_guest(&a, (uint8_t *)APTR(4)); }
    if (A32(5)) MEM32(A32(5)) = ipx ? 14 : 16;
    RET((uint32_t)n, 6);
}
static void w_recv(void) { ssize_t n = recv(fd_of(A32(0)), APTR(1), A32(2), MSG_DONTWAIT); if (n < 0) FAIL(4); RET((uint32_t)n, 4); }

/* Socket options: SOL_SOCKET is 0xFFFF on Winsock, and its option numbers are
 * BSD's own (SO_BROADCAST 0x20, SO_REUSEADDR 4, SO_RCVBUF 0x1002, ...). */
static int host_opt(uint32_t level, uint32_t opt, int *hl, int *ho) {
    if (level != 0xFFFFu) { *hl = (int)level, *ho = (int)opt; return 1; }
    *hl = SOL_SOCKET;
    switch (opt) {
    case 0x0004: *ho = SO_REUSEADDR; return 1;
    case 0x0020: *ho = SO_BROADCAST; return 1;
    case 0x1001: *ho = SO_SNDBUF; return 1;
    case 0x1002: *ho = SO_RCVBUF; return 1;
    case 0x1008: *ho = SO_TYPE; return 1;
    case 0x1007: *ho = SO_ERROR; return 1;
    default: return 0;
    }
}
static void w_setsockopt(void) {                         /* (s, level, opt, val, len) */
    int hl, ho, v = A32(3) ? (int)MEM32(A32(3)) : 0;
    if (A32(1) == NSPROTO_IPX) {                         /* the IPX options IPXEmu takes (and ignores) */
        if (A32(2) >= 0x4000u && A32(2) <= 0x4009u) RET(0, 5);
        g_wsa_error = 10042u;                            /* WSAENOPROTOOPT */
        RET(SOCKET_ERROR, 5);
    }
    if (!host_opt(A32(1), A32(2), &hl, &ho)) RET(0, 5);  /* an option a host lacks: accepted */
    if (setsockopt(fd_of(A32(0)), hl, ho, &v, sizeof v) != 0) FAIL(5);
    RET(0, 5);
}
static void w_getsockopt(void) {                         /* (s, level, opt, val, &len) */
    int hl, ho, v = 0;
    socklen_t l = sizeof v;
    if (A32(1) == NSPROTO_IPX) {
        uint32_t o = A32(3);
        if (A32(2) == 0x4007u && o) {                    /* IPX_ADDRESS: IPXEmu's one adapter */
            memset(hle_ptr(o), 0, 24);
            MEM8(o + 13) = 1;                            /* node 00:00:00:00:00:01 */
            MEM8(o + 15) = 1;                            /* status: up */
            MEM32(o + 16) = 1470, MEM32(o + 20) = 1000000;   /* max packet, link speed */
            RET(0, 5);
        }
        if (A32(2) == 0x400Du && o) { MEM32(o) = 1; RET(0, 5); }   /* IPX_MAX_ADAPTER_NUM */
        g_wsa_error = 10042u;
        RET(SOCKET_ERROR, 5);
    }
    if (host_opt(A32(1), A32(2), &hl, &ho) && getsockopt(fd_of(A32(0)), hl, ho, &v, &l) != 0) FAIL(5);
    if (A32(2) == 0x1008 && v == SOCK_DGRAM) v = 2;
    if (A32(3)) MEM32(A32(3)) = (uint32_t)v;
    if (A32(4)) MEM32(A32(4)) = 4;
    RET(0, 5);
}
static void w_ioctlsocket(void) {                        /* (s, cmd, &arg) */
    int fd = fd_of(A32(0));
    uint32_t cmd = A32(1);
    if (cmd == 0x8004667Eu) {                            /* FIONBIO */
        int fl = fcntl(fd, F_GETFL);
        fcntl(fd, F_SETFL, MEM32(A32(2)) ? fl | O_NONBLOCK : fl & ~O_NONBLOCK);
        RET(0, 3);
    }
    if (cmd == 0x4004667Fu) {                            /* FIONREAD */
        int n = 0;
        ioctl(fd, FIONREAD, &n);
        MEM32(A32(2)) = (uint32_t)n;
        RET(0, 3);
    }
    g_wsa_error = WSAEINVAL;
    RET(SOCKET_ERROR, 3);
}
static void w_getsockname(void) {
    struct sockaddr_in a;
    socklen_t l = sizeof a;
    if (getsockname(fd_of(A32(0)), (struct sockaddr *)&a, &l) != 0) FAIL(3);
    int ipx = is_ipx(fd_of(A32(0)));
    if (ipx) ipx_to_guest(&a, (uint8_t *)APTR(1), 1); else to_guest(&a, (uint8_t *)APTR(1));
    if (A32(2)) MEM32(A32(2)) = ipx ? 14 : 16;
    RET(0, 3);
}

static void w_htonl(void) { RET(htonl(A32(0)), 1); }
static void w_htons(void) { RET(htons((uint16_t)A32(0)), 1); }
static void w_ntohl(void) { RET(ntohl(A32(0)), 1); }
static void w_ntohs(void) { RET(ntohs((uint16_t)A32(0)), 1); }
static void w_inet_addr(void) { RET(ASTR(0) ? inet_addr(ASTR(0)) : 0xFFFFFFFFu, 1); }
static void w_inet_ntoa(void) {                          /* (in_addr by value) */
    static __thread char *buf;                           /* guest memory: the guest reads it */
    if (!buf) buf = (char *)hle_alloc(16);
    uint32_t a = A32(0);
    snprintf(buf, 16, "%u.%u.%u.%u", a & 255, (a >> 8) & 255, (a >> 16) & 255, a >> 24);
    RETP(buf, 1);
}
static void w_gethostname(void) {
    if (gethostname(ASTR(0), A32(1)) != 0) FAIL(2);
    RET(0, 2);
}
/* hostent, in guest-readable memory: name, aliases, addrtype(2), length(2),
 * addr_list. One per thread, as Winsock's is. */
static void w_gethostbyname(void) {
    typedef struct { uint32_t name, aliases; uint16_t type, len; uint32_t list; uint32_t lp[9]; uint32_t addr[8]; uint32_t none; char nm[256]; } guest_hostent;
    static __thread guest_hostent *he;
    if (!he) he = (guest_hostent *)hle_alloc(sizeof *he);
    const char *name = ASTR(0);
    struct hostent *h = name ? gethostbyname(name) : NULL;
    memset(he, 0, sizeof *he);
    he->name = hle_va(he->nm);
    he->aliases = hle_va(&he->none);
    he->type = 2, he->len = 4;
    he->list = hle_va(he->lp);
    if (h && h->h_addrtype == AF_INET) {
        snprintf(he->nm, sizeof he->nm, "%s", h->h_name);
        for (int i = 0; i < 8 && h->h_addr_list[i]; i++) {
            memcpy(&he->addr[i], h->h_addr_list[i], 4);
            he->lp[i] = hle_va(&he->addr[i]);
        }
        RETP(he, 1);
    }
    /* Windows always resolves its own name; a Mac's (a .local name) may not
     * be in the resolver gethostbyname uses, and a game that looks itself up
     * goes on as if it had an address (Yuri's Revenge's WOnline screen does).
     * Its own name is its interfaces' IPv4 addresses, or loopback. */
    char self[256];
    if (!name || gethostname(self, sizeof self) != 0 || strcasecmp(name, self)) { g_wsa_error = WSAHOST_NOT_FOUND; RET(0, 1); }
    snprintf(he->nm, sizeof he->nm, "%s", self);
    int n = 0;
    struct ifaddrs *ifs = NULL;
    if (getifaddrs(&ifs) == 0) {
        for (struct ifaddrs *i = ifs; i && n < 8; i = i->ifa_next)
            if (i->ifa_addr && i->ifa_addr->sa_family == AF_INET && !(i->ifa_flags & IFF_LOOPBACK) && (i->ifa_flags & IFF_UP))
                memcpy(&he->addr[n++], &((struct sockaddr_in *)i->ifa_addr)->sin_addr, 4);
        freeifaddrs(ifs);
    }
    if (!n) he->addr[n++] = htonl(INADDR_LOOPBACK);
    for (int i = 0; i < n; i++) he->lp[i] = hle_va(&he->addr[i]);
    RETP(he, 1);
}

/* ---- WSAAsyncSelect ---- */
#define MAX_ASYNC 32
static struct { uint32_t s, hwnd, msg, events; } g_async[MAX_ASYNC];

static void w_WSAAsyncSelect(void) {                     /* (s, hwnd, msg, events) */
    uint32_t s = A32(0);
    int fd = fd_of(s), slot = -1;
    if (fd < 0) { g_wsa_error = WSAENOTSOCK; RET(SOCKET_ERROR, 4); }
    fcntl(fd, F_SETFL, fcntl(fd, F_GETFL) | O_NONBLOCK);
    for (int i = 0; i < MAX_ASYNC; i++) if (g_async[i].s == s || (!g_async[i].s && slot < 0)) { slot = i; if (g_async[i].s == s) break; }
    if (slot < 0) { g_wsa_error = WSAEINVAL; RET(SOCKET_ERROR, 4); }
    g_async[slot].s = A32(3) ? s : 0;
    g_async[slot].hwnd = A32(1), g_async[slot].msg = A32(2), g_async[slot].events = A32(3);
    RET(0, 4);
}
static void w_WSACancelAsyncRequest(void) { g_wsa_error = WSAEINVAL; RET(SOCKET_ERROR, 1); }

/* From the message pump: a readable socket posts its message (once per
 * poll, as level-triggered FD_READ re-posts after each recv). */
void hle_ws_poll(void) {
    for (int i = 0; i < MAX_ASYNC; i++) {
        if (!g_async[i].s || !(g_async[i].events & FD_READ)) continue;
        struct pollfd p = { fd_of(g_async[i].s), POLLIN, 0 };
        if (poll(&p, 1, 0) == 1 && (p.revents & POLLIN))
            hle_post_message(g_async[i].hwnd, g_async[i].msg, g_async[i].s, FD_READ);
    }
}

/* EnumProtocolsA(protocols, buffer, &length): what IPXEmu answers, the IPX
 * entry (when IPX is asked for, or everything is), as a PROTOCOL_INFOA. */
static void w_EnumProtocolsA(void) {
    static uint32_t ipx_name;                            /* the guest keeps it */
    if (!ipx_name) ipx_name = hle_guest_strdup("IPX");
    uint32_t list = A32(0), buf = A32(1), lenp = A32(2), want = !list;
    for (uint32_t p = list; p && MEM32(p); p += 4) if (MEM32(p) == NSPROTO_IPX) want = 1;
    if (!want) RET(0, 3);
    if (!lenp || MEM32(lenp) < 32) { if (lenp) MEM32(lenp) = 32; g_wsa_error = 10055u /* WSAENOBUFS */; RET(SOCKET_ERROR, 3); }
    MEM32(buf) = 0x609, MEM32(buf + 4) = AF_IPX_WIN, MEM32(buf + 8) = 16, MEM32(buf + 12) = 14;
    MEM32(buf + 16) = 2, MEM32(buf + 20) = NSPROTO_IPX, MEM32(buf + 24) = 576, MEM32(buf + 28) = ipx_name;
    RET(1, 3);
}

/* select(nfds, read, write, except, timeout): Winsock's fd_set is a count and
 * an array of up to 64 SOCKETs (not a bitmap), timeval two 32-bit longs, a
 * NULL timeout waits for ever. Done with poll(); each set is rewritten to hold
 * only its ready sockets, and the total is returned. A wait gives the
 * machine to the other guest threads. */
static void w_select(void) {
    uint32_t set[3] = { A32(1), A32(2), A32(3) }, tv = A32(4);
    struct pollfd pf[192];
    int which[192], n = 0;
    for (int k = 0; k < 3; k++) {
        if (!set[k]) continue;
        uint32_t cnt = MEM32(set[k]);
        if (cnt > 64) cnt = 64;
        for (uint32_t i = 0; i < cnt; i++) {
            int fd = fd_of(MEM32(set[k] + 4 + 4 * i));
            if (fd < 0) { g_wsa_error = WSAENOTSOCK; RET(SOCKET_ERROR, 5); }
            pf[n].fd = fd, pf[n].revents = 0;
            pf[n].events = k == 0 ? POLLIN : k == 1 ? POLLOUT : POLLPRI;
            which[n++] = k;
        }
    }
    int ms = tv ? (int)(MEM32(tv) * 1000u + MEM32(tv + 4) / 1000u) : -1;
    if (ms) hle_block_begin();
    int r = poll(pf, (nfds_t)n, ms);
    if (ms) hle_block_end();
    if (r < 0) FAIL(5);
    uint32_t total = 0, out[3] = { 0, 0, 0 };
    for (int j = 0; j < n; j++) {
        short ev = pf[j].revents;
        int k = which[j];
        int ready = k == 0 ? (ev & (POLLIN | POLLHUP | POLLERR)) != 0
                  : k == 1 ? (ev & (POLLOUT | POLLERR)) != 0 : (ev & (POLLPRI | POLLERR)) != 0;
        if (ready) MEM32(set[k] + 4 + 4 * out[k]++) = (uint32_t)pf[j].fd + SOCK_BASE, total++;
    }
    for (int k = 0; k < 3; k++) if (set[k]) MEM32(set[k]) = out[k];
    RET(total, 5);
}

#define SHIM2(ord, name, fn) { "wsock32.dll#" #ord, fn }, { name, fn }
const win32hle_shim win32hle_wsock32[] = {
    SHIM2(1111, "EnumProtocolsA", w_EnumProtocolsA),
    SHIM2(2, "bind", w_bind),
    SHIM2(3, "closesocket", w_closesocket),
    SHIM2(4, "connect", w_connect),
    SHIM2(6, "getsockname", w_getsockname),
    SHIM2(7, "getsockopt", w_getsockopt),
    SHIM2(8, "htonl", w_htonl),
    SHIM2(9, "htons", w_htons),
    SHIM2(10, "inet_addr", w_inet_addr),
    SHIM2(11, "inet_ntoa", w_inet_ntoa),
    SHIM2(12, "ioctlsocket", w_ioctlsocket),
    SHIM2(13, "listen", w_listen),
    SHIM2(14, "ntohl", w_ntohl),
    SHIM2(15, "ntohs", w_ntohs),
    SHIM2(16, "recv", w_recv),
    SHIM2(17, "recvfrom", w_recvfrom),
    SHIM2(18, "select", w_select),
    SHIM2(19, "send", w_send),
    SHIM2(20, "sendto", w_sendto),
    SHIM2(21, "setsockopt", w_setsockopt),
    SHIM2(23, "socket", w_socket),
    SHIM2(52, "gethostbyname", w_gethostbyname),
    SHIM2(57, "gethostname", w_gethostname),
    SHIM2(101, "WSAAsyncSelect", w_WSAAsyncSelect),
    SHIM2(108, "WSACancelAsyncRequest", w_WSACancelAsyncRequest),
    SHIM2(111, "WSAGetLastError", w_WSAGetLastError),
    SHIM2(112, "WSASetLastError", w_WSASetLastError),
    SHIM2(115, "WSAStartup", w_WSAStartup),
    SHIM2(116, "WSACleanup", w_WSACleanup),
    { 0, 0 }
};
